/*
 * delay_uS.h
 *
 *  Created on: Nov 7, 2017
 *      Author: Ocanath
 */

#ifndef DELAY_US_H_
#define DELAY_US_H_

void delay_T14_us(int cycles);
unsigned long int TIM14_ms();

#endif /* DELAY_US_H_ */
