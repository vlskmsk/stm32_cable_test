/*
 * sig-injection.c
 *
 *  Created on: Jul 12, 2018
 *      Author: Ocanath
 */
#include "init.h"
#include "foc_commutation.h"

float cV[6] = {.5, -.5, -1, -.5, .5, 1};
float sV[6] = {SQRT_3_BY_2, SQRT_3_BY_2, 0, -SQRT_3_BY_2, -SQRT_3_BY_2, 0};
