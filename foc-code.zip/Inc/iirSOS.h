/*
 * iirSOS.h
 *
 *  Created on: May 9, 2018
 *      Author: Ocanath
 */

#ifndef IIRSOS_H_
#define IIRSOS_H_

#define BUF_SIZE 3

//typedef struct iirSOS_buf
//{
//	int write_idx;
//	int buf[BUF_SIZE];
//}iirSOS_buf;

typedef struct iirSOS
{
	float a1,a2;
	float b0,b1,b2;
	float gain;
	float w[3];
//	int a1,a2;
//	int b0,b1,b2;
//	int w[3];
}iirSOS;

typedef struct iirSOS_fast
{
	int a1,a2;
	int b0,b1,b2;
	int shift;
	int w[3];
}iirSOS_fast;

float sos_f(iirSOS * f, float newSample);


#endif /* IIRSOS_H_ */
